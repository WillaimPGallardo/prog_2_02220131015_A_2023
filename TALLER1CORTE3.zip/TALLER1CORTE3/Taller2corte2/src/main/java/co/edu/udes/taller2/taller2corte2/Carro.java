/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udes.taller2.taller2corte2;

/**
 *
 * @author usuario
 */
public class Carro {
    
    private String marca;
     private String modelo;
     private String colorrr;
     private String bodyyy;
     private String interior;
     private String transmision;
     private int placa;
     private int fuerza;
     private int kilometraje;
     private String sistemaselectrico;
    
    

     private String mark;
     private String model;
     private String color;
     private String body;
     private String interiors;
     private String transmission;
     private int plate;
     private int power;
     private int mileage;
     private String electricSystem;
     
    
}
