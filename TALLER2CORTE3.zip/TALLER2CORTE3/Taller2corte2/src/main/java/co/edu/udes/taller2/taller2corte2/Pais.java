/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udes.taller2.taller2corte2;

/**
 *
 * @author usuario
 */
public class Pais {
    
    private String name;
    private String continent;
    private int population;
    private double area;
    private float location;
    private int departaments;
    private int citys;
    private String anthem;
    private int density;
    private int altitude;
    private int temperature;
    private int humidity;
    private int pressure;
    
    
}
