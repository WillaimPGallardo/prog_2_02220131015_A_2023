/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udes.taller2.taller2corte2;

/**
 *
 * @author usuario
 */
public class Empresa {
    
    private String name;
    private String code;
    private String type;
    private String price;
    private String country;
    private String slogan;
    private int partners;
    private int workers;
    private float money;
    private int branchOffices;
    private String addres;
    
}
