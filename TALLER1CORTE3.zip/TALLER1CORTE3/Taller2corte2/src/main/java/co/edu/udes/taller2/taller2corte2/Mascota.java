/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udes.taller2.taller2corte2;

/**
 *
 * @author usuario
 */
public class Mascota {
    
    private String name;
    private String type;
    private String breed;
    private String color;
    private String size;
    private String weight;
    private String age;
    private String gender;
    private String owner;
     
    
}
