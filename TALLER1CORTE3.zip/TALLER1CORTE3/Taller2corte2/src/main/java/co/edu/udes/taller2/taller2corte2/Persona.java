/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udes.taller2.taller2corte2;

/**
 *
 * @author usuario
 */
public class Persona {
    
    private String name;
    private String lastName;
    private String documentType;
    private int documentNumber;
    private int age;
    private String nationality;
    private String addres;
    private String hairColor;
    private String eyeColor;
    private String gender;
    private double height;
    private double weight;
    private String skincolor;
    
}
