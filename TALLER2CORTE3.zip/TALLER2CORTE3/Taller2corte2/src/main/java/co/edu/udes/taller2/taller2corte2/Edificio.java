/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udes.taller2.taller2corte2;

/**
 *
 * @author usuario
 */
public class Edificio {
    
    
    private String buildingType;
    private int workers;
    private int windows;
    private String aqueduct;
    private String electricSystem;
    private String addres;
    private String name;
    private double height;
    private String structureType;
    private String securityType;
    private double area;
    private int capacity;
     
}
