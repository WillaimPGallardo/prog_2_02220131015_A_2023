/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udes.taller2.taller2corte2;

/**
 *
 * @author usuario
 */
public class Computador {
    
    private String graphicCard;
    private int graphicCardCapacity;
    private String monitor;
    private int SizeMonitor;
    private String keyboard;
    private String mouse;
    private String processor;
    private String board;
    private String powerFount;
    private int batery;
    private String type;
    private String model;
    private String mark;
    private String color;
    private String screenType;
    private String ramType;
    private int ram;
    private String storageType;
    private int storage;
    
}
