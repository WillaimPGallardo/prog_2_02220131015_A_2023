/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udes.taller2.taller2corte2;

/**
 *
 * @author usuario
 */
public class Asignatura {
    
    private String name;
    private String code;
    private int credits;
    private int semester;
    private String teacher;
    private int teacherCode;
    private int hours;
    private String description;
    
    
   
    
}
