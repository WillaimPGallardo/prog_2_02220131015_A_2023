/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package co.edu.udes.taller2.taller2corte2;

/**
 *
 * @author usuario
 */
public class Ciudad {
    
    private String name;
    private String country;
    private int temperature;
    private int humidity;
    private int pressure;
    private float location;
    private int timeZone;
    private int population;
    private double area;
    private int density;
    private int altitude;
    
    
}
